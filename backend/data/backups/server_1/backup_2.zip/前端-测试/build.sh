npm config set strict-ssl false && \
npm config set unsafe-perm true && \
npm install --registry=https://registry.npmmirror.com && \
npm run build:test
#npm config set strict-ssl false && \
#npm config set unsafe-perm true && \
#npm install --registry=https://registry.npmmirror.com && \
#npm run build:test
#!/bin/bash


#!/bin/bash

# 检查当前目录是否存在 Dockerfile
if [ ! -f "Dockerfile" ]; then
    echo "=============== Dockerfile 不存在，正在生成... ==============="
    cat > Dockerfile <<EOF
FROM 10.114.233.12/basic/nginx:1.28.0
LABEL maintainer="admin@kmbt.com"
WORKDIR /data
COPY dist ./h5mall
RUN chown -R nginx:nginx /data
EXPOSE 80
CMD ["nginx", "-g", "daemon off;"]
EOF
    echo "=============== Dockerfile 已生成 ==============="
else
    echo "=============== 当前目录已存在 Dockerfile，跳过生成步骤 ==============="
fi
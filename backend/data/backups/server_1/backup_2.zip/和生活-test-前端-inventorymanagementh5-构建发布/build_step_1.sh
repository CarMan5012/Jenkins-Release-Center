#!/bin/bash
# 检查当前目录是否存在 Dockerfile
if [ ! -f "Dockerfile" ]; then
    echo "=============== Dockerfile 不存在，正在生成... ==============="
    cat > Dockerfile <<EOF
FROM 10.114.233.12/baisc/node:22-alpine AS builder
WORKDIR /app
COPY . .
ARG BUILD_ENV=test

RUN yarn config set registry https://registry.npmmirror.com && \
    rm -rf node_modules package-lock.json yarn.lock && \
    yarn install --ignore-engines && \
    yarn run build:${BUILD_ENV}

FROM 10.114.233.12/baisc/nginx:1.28.0
MAINTAINER kmbt admin@kmbt.com
WORKDIR /data
COPY --from=builder /app/dist ./inventorymanagementh5
RUN chown -R nginx:nginx /data
EOF
    echo "=============== Dockerfile 已生成 ==============="
else
    echo "=============== 当前目录已存在 Dockerfile，跳过生成步骤 ==============="
fi
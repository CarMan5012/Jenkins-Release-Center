#!/bin/bash
cat > Dockerfile <<EOF
FROM 10.114.233.12/baisc/nginx:1.28.0
WORKDIR /data
COPY dist ./rightsgrid
RUN chown -R nginx:nginx /data
EXPOSE 80
CMD ["nginx", "-g", "daemon off;"]
EOF

#!/bin/bash
cat > Dockerfile <<EOF
FROM 10.114.233.12/baisc/kmbtjdk:v1
ENV TZ=Asia/Shanghai
WORKDIR /
COPY trunk/api-gateway/target/api-gateway.jar app.jar
ENTRYPOINT ["java", "-jar", "app.jar"]
EOF

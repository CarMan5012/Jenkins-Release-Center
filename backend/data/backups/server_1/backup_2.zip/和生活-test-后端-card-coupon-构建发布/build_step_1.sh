#!/bin/bash
cat > Dockerfile <<EOF
FROM 10.114.233.12/baisc/kmbtjdk:v1
ENV TZ=Asia/Shanghai
WORKDIR /
COPY trunk/ydmall-service/card-coupon/target/card-coupon.jar app.jar
ENTRYPOINT ["java", "-jar", "app.jar"]
EOF

#!/bin/bash
# 【安全开关】
set -euo pipefail

# ============================================================================
# 环境与基础配置
NAMESPACE="gdbtest"                                            # 命名空间 (例如: test,dev,prod)
DEPLOYMENT_NAME="file-center"                              # K8s Deployment 名称
CONTAINER_NAME="file-center"                               # K8s 容器名称
IMAGE_REPO="10.114.233.12/${NAMESPACE}/${DEPLOYMENT_NAME}"     # 镜像仓库地址

# 配置 Kuboard API 地址和参数
KUBOARD_API_HOST="http://10.114.185.169:30080"                 # Kuboard 服务器地址
KUBOARD_CLUSTER="hsh-test"                                     # 目标集群名称
API_URL="${KUBOARD_API_HOST}/kuboard-api/cluster/${KUBOARD_CLUSTER}/kind/CICDApi/admin/resource/updateImageTag"
# 获取 Jenkins 注入的 API 认证密钥 (增加容错，避免 set -u 报错)
KUBOARD_KEY="${KUBOARD_ACCESS_KEY_TEST:-}"

# 动态变量生成镜像 TAG
# 提取 Jenkins Git 插件注入的 COMMIT HASH 前 7 位 (增加防崩溃默认值处理)
RAW_GIT_COMMIT="${GIT_COMMIT:-nogit0000}"
GIT_HASH="${RAW_GIT_COMMIT:0:7}"
BUILD_NUM="${BUILD_NUMBER:-local}"
IMAGE_TAG="${GIT_HASH}-b${BUILD_NUM}"
FINAL_IMAGE="${IMAGE_REPO}:${IMAGE_TAG}"

# 生成唯一临时响应记录文件
TEMP_RESPONSE_FILE="/tmp/kuboard_response_${BUILD_NUM}_$$.txt"
# ============================================================================

echo "================================================="
echo "【INFO】目标环境 (Namespace): ${NAMESPACE}"
echo "【INFO】目标代码版本 (Git): ${GIT_HASH}"
echo "【INFO】当前构建批次: ${BUILD_NUM}"
echo "【INFO】最终镜像名称: ${FINAL_IMAGE}"
echo "================================================="

echo "=============== 开始构建镜像... ==============="
docker build --network=host -t ${FINAL_IMAGE} . || {
    echo "【ERROR】镜像构建失败！"
    exit 1
}

echo "=============== 开始推送镜像... ==============="
HARBOR_USER="${HARBOR_USERNAME:-admin}"
HARBOR_PASS="${HARBOR_PASSWORD:-Harbor12345}"
echo "${HARBOR_PASS}" | docker login 10.114.233.12 -u "${HARBOR_USER}" --password-stdin

docker push ${FINAL_IMAGE} || {
    echo "【ERROR】镜像推送失败！"
    exit 1
}

echo "=============== 清理本地构建机的旧镜像，释放磁盘空间... ==============="
docker rmi ${FINAL_IMAGE} 2>/dev/null || true
docker image prune -f

echo "=============== 调用 Kuboard API 更新集群镜像... ==============="
HTTP_CODE=$(curl -s -w "%{http_code}" -o "${TEMP_RESPONSE_FILE}" -X PUT \
    -H "content-type: application/json" \
    -H "Cookie: KuboardUsername=admin; KuboardAccessKey=${KUBOARD_KEY}" \
    -d '{
        "kind": "deployments",
        "namespace": "'${NAMESPACE}'",
        "name": "'${DEPLOYMENT_NAME}'",
        "images": {
            "'${CONTAINER_NAME}'": "'${FINAL_IMAGE}'"
        }
    }' \
    "${API_URL}")

# 部署状态检查
if [ "$HTTP_CODE" == "200" ]; then
    echo "【SUCCESS】恭喜！应用部署已成功触发！"
    echo "-------------------------------------------------"
    echo "  * 环境 (Namespace): ${NAMESPACE}"
    echo "  * 应用 (Deployment): ${DEPLOYMENT_NAME}"
    echo "  * 容器 (Container): ${CONTAINER_NAME}"
    echo "  * 集群 (Cluster): ${KUBOARD_CLUSTER}"
    echo "  * Kuboard 地址 (Kuboard API Host): ${KUBOARD_API_HOST}"
    echo "  * 镜像版本 (Image Tag): ${IMAGE_TAG}"
    echo "  * 完整镜像地址 (Full Image): ${FINAL_IMAGE}"
    echo "-------------------------------------------------"
else
    echo "【ERROR】Kuboard API 调用失败！HTTP 状态码: ${HTTP_CODE}"
    echo "【ERROR】Kuboard 接口返回信息如下："
    cat "${TEMP_RESPONSE_FILE}"
    rm -f "${TEMP_RESPONSE_FILE}"
    exit 1
fi

# 运行成功后清理临时响应记录文件
rm -f "${TEMP_RESPONSE_FILE}"
#!/bin/bash
cat > Dockerfile <<EOF
FROM 10.114.233.12/baisc/kmbtjdk:v1
ENV TZ=Asia/Shanghai
WORKDIR /
COPY hshright-modules/hshright-file/target/hshright-modules-file.jar app.jar
ENTRYPOINT ["java", "-jar", "app.jar"]
EOF

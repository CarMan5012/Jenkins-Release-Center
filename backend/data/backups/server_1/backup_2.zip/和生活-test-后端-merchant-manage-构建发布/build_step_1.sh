#!/bin/bash
cat > Dockerfile <<EOF
FROM 10.114.233.12/baisc/kmbtjdk:v1
WORKDIR /
COPY trunk/ydmall-service/merchant-manage/target/merchant-manage.jar app.jar
ENTRYPOINT ["java", "-jar", "app.jar"]
EOF
#!/bin/bash
cat > Dockerfile <<EOF
FROM 10.114.233.12/baisc/kmbtjdk:v1
ENV TZ=Asia/Shanghai
WORKDIR /
COPY trunk/business-center/open-center/target/open-center.jar app.jar
ENTRYPOINT ["java", "-jar", "app.jar"]
EOF
